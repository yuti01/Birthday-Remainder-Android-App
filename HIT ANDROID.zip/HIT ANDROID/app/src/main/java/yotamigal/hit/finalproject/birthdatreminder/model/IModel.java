package yotamigal.hit.finalproject.birthdatreminder.model;

import yotamigal.hit.finalproject.birthdatreminder.exception.HITMOBILEException;

/**
 * Every class that implements this interface is a valid
 * Model for this project
 */
public interface IModel {

    /**
     * This method puts Contact in the data base
     * @param contact the Contact to put inside the data base
     */
    public void putContactInDB(Contact contact);

    /**
     * This method gets a specific Contact from the data base found by the phone number of the Contact
     * @param phoneNumber a String representing the phone number of the Contact that the method returns
     * @return a Contact object with the data from the data base with the specified phone number
     */
    public Contact getContactFromDB(String phoneNumber);

    /**
     * Get all the Contacts from the database
     * @return a ContactList object containing all the Contacts from the database
     */
    public ContactList getAllContactFromDB();

    /**
     * get the number of Contacts in the database
     * @return an integer representing the number of Contacts in the database
     */
    public int getNumOfContacts();

    /**
     * delete a Contact from the database
     * @param phoneNumber a String representing the phone number of the Contact to be deleted
     * @throws HITMOBILEException if the deletion went wrong
     */
    public void deleteSingleContact(String phoneNumber) throws HITMOBILEException;

    /**
     * This method clears the database - delete all rows
     */
    public void clearTheDataBase();
}
