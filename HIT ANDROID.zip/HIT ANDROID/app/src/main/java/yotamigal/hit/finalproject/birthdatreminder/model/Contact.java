package yotamigal.hit.finalproject.birthdatreminder.model;

import android.webkit.JavascriptInterface;

import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;

import yotamigal.hit.finalproject.birthdatreminder.exception.HITMOBILEException;

/**
 * This class represents a contact
 * a single Contact has: first name, last name, gender, date of birth and a phone number.
 */
public class Contact {

    /**
     * firstName is a String representing the first name of this contact
     * lastName is a String representing the last name of this contact
     * gender is a Gender enum type representing the gender of this Contact
     * dateOfBirth is a LocalDate representing the data of birth of this Contact
     * phoneNumber is a String representing the phoneNumber of this Contact
     */
    private String firstName; // the first name of this Contact

    private String lastName; // the last name of this Contact

    private Gender gender; // the Gender of this Contact

    private LocalDate dateOfBirth; // a LocalDate representing the data of birth of this Contact

    private String phoneNumber; // a String representing the phoneNumber of this Contact

    private final static String regex = "^[0-9]*$"; // a regular expression which means only numbers
    private final static int phoneNumberLength = 10; // the max length of a phone number

    /**
     * The constructor of this class
     * @param firstName a String representing the first name of this contact
     * @param lastName a String representing the last name of this contact
     * @param gender a Gender enum type representing the gender of this Contact
     * @param dateOfBirth a LocalDate representing the data of birth of this Contact
     * @param phoneNumber a String representing the phoneNumber of this Contact
     * @throws HITMOBILEException if he phone number is not in the right format
     */
    public Contact(String firstName, String lastName, Gender gender, LocalDate dateOfBirth, String phoneNumber) throws HITMOBILEException {

        // set every field
        setFirstName(firstName);
        setLastName(lastName);
        setGender(gender);
        setDateOfBirth(dateOfBirth);

        // is the phoneNumber String matches the phone number format
        if(phoneNumber.matches(regex) && phoneNumber.length() == phoneNumberLength)
            setPhoneNumber(phoneNumber); // set the phone number
        else throw new HITMOBILEException("phone number is not valid"); // throw an exception
    }

    /**
     * getter for the "firstName" field
     * @return a String representing the firstName of this Contact
     */
    @JavascriptInterface
    public String getFirstName() {
        return firstName;
    }

    /**
     * A setter of the "firesName" field
     * @param firstName a String to be the new firstName
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * getter for the "lastName" field
     * @return a String representing the firstName of this Contact
     */
    @JavascriptInterface
    public String getLastName() {
        return lastName;
    }

    /**
     * A setter of the "firesName" field
     * @param lastName a String to be the new lastName
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * getter for the "gender" field
     * @return a Gender enum type to be the new gender of this Contact
     */
    @JavascriptInterface
    public Gender getGender() {
        return gender;
    }

    /**
     * get the gender as a String
     * @return a String representing the gender of this Contact
     */
    @JavascriptInterface
    public String getGenderAsString() { return gender.toString(); }

    /**
     * A setter for the "gender" field
     * @param gender a Gender enum type to be the new gender of this Contact
     */
    public void setGender(Gender gender) {
        this.gender = gender; // set the gender
    }

    /**
     * get the "dataOfBirth" field
     * @return a LocalDate object representing the date of birth of this Contact
     */
    @JavascriptInterface
    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * A setter for the "dateOfBirth"
     * @param dateOfBirth a LocalDate object to be the new dateOfBirth of this Contact
     */
    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth; // set the birth date
    }

    /**
     * get the phone number of this Contact
     * @return the phone number of this Contact
     */
    @JavascriptInterface
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * A setter for the "phoneNumber" field
     * @param phoneNumber a String representing the phone number of this Contact
     */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber; // set the phone number
    }

    /**
     * compares between two Contacts.
     * @param o the Object we compare this Contact to.
     * @return true - equal
     *         false - otherwise
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true; // same object

        // null object or not an instance of the Contact class
        if (o == null || getClass() != o.getClass()) return false;

        Contact contact = (Contact) o; // get the given Contact by casting

        // if all the field are equal - return true
        //                       else - return false
        return  firstName.equals(contact.getFirstName()) &&
                lastName.equals(contact.getLastName()) &&
                gender == contact.getGender() &&
                dateOfBirth.equals(contact.getDateOfBirth()) &&
                phoneNumber.equals(contact.getPhoneNumber());
    }

    /**
     * calculates the age of a specific Contact using the date of birth and the current date.
     * @param currentDate a LocalDate representing the current date.
     * @return an integer contains the age of the Contact
     */
    @JavascriptInterface
    public int calculateAge(LocalDate currentDate){
        if ((getDateOfBirth() != null) && (currentDate != null)) { // if it is possible to calculate
            return Period.between(getDateOfBirth(),currentDate).getYears(); // return the period between the two dates

        }
            return 0; // else return 0
    }

    /**
     * calculates the age of a specific Contact using the date of birth and the current date (got from android os).
     * @return an integer contains the age of the Contact
     */
    @JavascriptInterface
    public int calculateAge(){
        if (getDateOfBirth() != null) { // if it is possible to calculate -  return the period between the two dates: current and birth date
            LocalDate currentDate = Calendar.getInstance().getTime().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            return Period.between(getDateOfBirth(),currentDate).getYears();

        }

        return 0;
    }

    /**
     * get the days until this Contact birth day
     * @return a long number representing the days until this Contact birth day
     */
    @JavascriptInterface
    public long getDaysUntilBirthday(){
        if (getDateOfBirth() != null) { // if birth day is not null

            // get the current date
            LocalDate currentDate = Calendar.getInstance().getTime().toInstant().atZone(ZoneId.systemDefault()).toLocalDate();

            // calculate the next birthday
            LocalDate nextBDay = getDateOfBirth().withYear(currentDate.getYear());

            // If the birthday has occurred this year already, add 1 to the year.
            if (nextBDay.isBefore(currentDate) || nextBDay.isEqual(currentDate)) {
                nextBDay = nextBDay.plusYears(1);
            }

            // return the days between the current day and the next birthday:
            return ChronoUnit.DAYS.between(currentDate, nextBDay);

        }
        return 0; // birth day is null - return 0
    }

    /**
     * get the days until this Contact`s birthday as a String
     * @return a String representing the days until this Contact`s birthday
     */
    @JavascriptInterface
    public String getDaysUntilBirthdayAsString(){
        return String.valueOf(getDaysUntilBirthday());
    }

    /**
     * get the date of birth of this Contact as a String
     * @return a String representing this Contact`s date of birth
     */
    @JavascriptInterface
    public String getDateOfBirthAsString(){
        return getDateOfBirth().toString();
    }
}
