package yotamigal.hit.finalproject.birthdatreminder.exception;

/**
 * The exception class of this project
 */
public class HITMOBILEException extends Exception {

    /**
     * create new HITMOBILEException with no attributes
     */
    public HITMOBILEException() {
        super();
    }

    /**
     * create new HITMOBILEException with a message (String)
     */
    public HITMOBILEException(String message) {
        super(message);
    }

    /**
     * create new HITMOBILEException with a message (String) and a cause (Throwable)
     */
    public HITMOBILEException(String message, Throwable cause) {
        super(message, cause);
    }
}
