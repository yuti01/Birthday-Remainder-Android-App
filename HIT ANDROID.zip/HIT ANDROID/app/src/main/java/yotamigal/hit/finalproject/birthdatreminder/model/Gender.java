package yotamigal.hit.finalproject.birthdatreminder.model;

import android.webkit.JavascriptInterface;

/**
 * a specific gender can and should be represented by the corresponding Gender enum type
 */
public enum Gender {
    /**
     * Male - a man
     */
    Male,

    /**
     * Female - a woman
     */
    Female;

    /**
     * This method return a String representing this Gender enum type
     * @return a String representing this Gender enum type
     */
    @JavascriptInterface
    @Override
    public String toString() {
        if(this == Gender.Male) return "Male"; // if its a Male return - "Male"

        return "Female";
    }

    /**
     * this static method returns a Gender enum type according to the String input
     * @param genderString a String "Male" or "Female" to parse
     * @return a Gender enum type according to the String input
     */
    @JavascriptInterface
    public static Gender parseString(String genderString){
        if (genderString.equals("Male")) return Gender.Male; // input = "Male" - return Male

        else return Gender.Female; // else return Female
    }
}
