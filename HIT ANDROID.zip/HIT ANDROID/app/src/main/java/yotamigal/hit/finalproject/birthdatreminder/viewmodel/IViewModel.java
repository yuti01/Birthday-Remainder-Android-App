package yotamigal.hit.finalproject.birthdatreminder.viewmodel;

import android.webkit.JavascriptInterface;

/**
 * Every class that implements this interface is a valid
 * ViewModel for this project
 */
public interface IViewModel {

    /**
     * Initialize the Main Contact ListView
     */
    @JavascriptInterface
    public void initializeTheContactListView();

    /**
     * Send a new Contact to the database and add it to the contact list in the view
     * @param firstName a String representing the first name of the Contact
     * @param lastName a String representing the lasr name of the Contact
     * @param gender a String representing the gender of the Contact
     * @param dateOfBirth a String representing the date of birth of the Contact
     * @param phoneNumber a String representing the phone number of the Contact
     */
    @JavascriptInterface
    public void sendNewContactToDBAndAddItToTheContactList(final String firstName, final String lastName, final String gender,
                                   final String dateOfBirth, final String phoneNumber);


    /**
     * Delete a single Contact by its phone number
     * @param phoneNumber a String representing the phone number of the Contact to be deleted
     */
    @JavascriptInterface
    public void deleteContactByPhoneNumber(final String phoneNumber);

    /**
     * Show confirmation message (new contact added)
     */
    @JavascriptInterface
    public void showConfirmContactAddedMessage();

    /**
     * Show Error message (new contact could not be added)
     */
    @JavascriptInterface
    public void showErrorContactNotAddedMessage();

    /**
     * Show confirmation message (contact deleted)
     */
    public void showConfirmContactDeletedMessage();
}
