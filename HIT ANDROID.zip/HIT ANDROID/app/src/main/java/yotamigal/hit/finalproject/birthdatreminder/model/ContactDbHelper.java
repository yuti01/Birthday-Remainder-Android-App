package yotamigal.hit.finalproject.birthdatreminder.model;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * This class helps us to manage the SQLite database
 */
public class ContactDbHelper extends SQLiteOpenHelper {

    /**
     * SQL_CREATE_ENTRIES - the SQL statement to create the table
     */
    // Create the data base with this SQL query
    String SQL_CREATE_ENTRIES = "CREATE TABLE " + ContactContract.ContactEntry.TABLE_NAME + "(" +
            ContactContract.ContactEntry.COLUMN_PHONE_NUMBER + " TEXT PRIMARY KEY," +
            ContactContract.ContactEntry.COLUMN_FIRST_NAME + " TEXT NOT NULL," +
            ContactContract.ContactEntry.COLUMN_LAST_NAME + " TEXT NOT NULL," +
            ContactContract.ContactEntry.COLUMN_GENDER +" TEXT NOT NULL," +
            ContactContract.ContactEntry.COLUMN_DATE_OF_BIRTH + " TEXT NOT NULL);";

    /**
     * SQL_DELETE_ENTRIES - the SQL statement to drop the table
     */
    // Delete the data base with this SQL query
    String SQL_DELETE_ENTRIES = "DROP TABLE IF EXISTS " + ContactContract.ContactEntry.TABLE_NAME + ";";


    /**
     * DATABASE_VERSION is the version of the database
     * DATABASE_NAME is the database name
     */
    // If you change the database schema, you must increment the database version.
    public static final int DATABASE_VERSION = 4;
    public static final String DATABASE_NAME = "contacts.db"; // the name of the database

    /**
     * this method is called after the helper created
     * @param db the SQLiteDatabase this helper manages
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_ENTRIES); // create the table
        Log.i("tag","database created"); // log info
    }

    /**
     * The Constructor of this class
     * @param context the Context of the helper
     */
    public ContactDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * This method is called if the version of the database changed
     * @param db the SQLiteDatabase to be upgraded
     * @param oldVersion the old version of the database
     * @param newVersion the new version of the database
     */
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // This database is only a cache for online data, so its upgrade policy is
        // to simply to discard the data and start over
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
        Log.i("tag","database upgraded"); // log info
    }

    /**
     * This method is called if the version of the database changed
     * @param db the SQLiteDatabase to be downgraded
     * @param oldVersion the old version of the database
     * @param newVersion the new version of the database
     */
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }
}



