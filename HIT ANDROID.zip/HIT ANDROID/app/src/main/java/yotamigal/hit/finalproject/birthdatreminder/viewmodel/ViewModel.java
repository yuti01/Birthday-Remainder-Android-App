package yotamigal.hit.finalproject.birthdatreminder.viewmodel;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import java.time.LocalDate;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import yotamigal.hit.finalproject.birthdatreminder.exception.HITMOBILEException;
import yotamigal.hit.finalproject.birthdatreminder.model.Contact;
import yotamigal.hit.finalproject.birthdatreminder.model.ContactList;
import yotamigal.hit.finalproject.birthdatreminder.model.Gender;
import yotamigal.hit.finalproject.birthdatreminder.model.IModel;

/**
 * This class is the ViewModel class for this project
 */
public class ViewModel implements IViewModel{

    /**
     * model - the Model associated with this ViewModel instance
     * view - the WebView associated with this ViewModel instance
     * theActivity - the context associated with this ViewModel instance
     * threadPool -  a ThreadPool we will use to execute Threads
     */
    private IModel model; // the Model associated with this ViewModel instance
    private WebView view; // the WebView associated with this ViewModel instance
    private Activity theActivity; // the context associated with this ViewModel instance

    // a ThreadPool we will use to execute Threads
    private ExecutorService threadPool = Executors.newCachedThreadPool();

    /**
     * The ViewModel constructor
     * @param model an IModel to be associated with this instance
     * @param view a WebView object to be associated with this instance
     */
    public ViewModel(IModel model, WebView view, Activity theActivity) {
        this.model = model; // set the model
        this.view = view; // set the view
        this.theActivity = theActivity; // set the activity

    }

    /**
     * Send a new Contact to the database
     * @param firstName a String representing the first name of the Contact
     * @param lastName a String representing the lasr name of the Contact
     * @param gender a String representing the gender of the Contact
     * @param dateOfBirth a String representing the date of birth of the Contact
     * @param phoneNumber a String representing the phone number of the Contact
     */
    @Override
    @JavascriptInterface
    public void sendNewContactToDBAndAddItToTheContactList(final String firstName, final String lastName, final String gender,
                                   final String dateOfBirth, final String phoneNumber){

        threadPool.submit(new Runnable() { // send a new Contact in another thread
            @Override
            public void run() {
                Log.i("tag","Starting the thread that puts a Contact in the data base"); // log info
                try {
                    // create a new Contact
                    final Contact contact = new Contact(firstName,lastName,Gender.parseString(gender),
                            LocalDate.parse(dateOfBirth),phoneNumber);

                    // send it to the database
                    model.putContactInDB(contact);

                    theActivity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() { // in the UI thread - run JavaScript to add a new Contact
                            view.evaluateJavascript("javascript:hit.addContact('" +
                                            contact.getFirstName() + "','"
                                            + contact.getLastName() + "','"
                                            + contact.getDateOfBirthAsString() + "','"
                                            + contact.getGenderAsString() + "','"
                                            + contact.getPhoneNumber() + "','"
                                            + contact.getDaysUntilBirthdayAsString() + "');"
                                    ,null);
                        }
                    });

                    showConfirmContactAddedMessage(); // show confirm message

                } catch (HITMOBILEException e) {
                    Log.e("tag","phone number format error"); // log error
                    showErrorContactNotAddedMessage(); // show error message
                }
            }
        });

    }

    /**
     * Initialize the Main Contact ListView
     */
    @Override
    @JavascriptInterface
    public void initializeTheContactListView(){
        threadPool.submit(new Runnable() {
            @Override
            public void run() {
                Log.i("tag", "running in another thread to initialize the list");

                // getting the all the Contacts form the database
                //final ContactList theContactListToShow = model.getAllContactFromDB();
                final ContactList theContactListToShow = model.getAllContactFromDB();

                Log.i("tag","Got all the Contacts from the database");

                // run the initialization on the UI thread
                theActivity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Log.i("tag","Adding the ContactList to the JavaScript");

                        // add the ContactList object to the JavaScript code
                        Log.i("tag","Initializing List");

                        // initialize the ListView
                        for (Contact curentContactToAdd : theContactListToShow){
                            view.evaluateJavascript("javascript:hit.addContact('" +
                                    curentContactToAdd.getFirstName() + "','"
                                    + curentContactToAdd.getLastName() + "','"
                                    + curentContactToAdd.getDateOfBirthAsString() + "','"
                                    + curentContactToAdd.getGenderAsString() + "','"
                                    + curentContactToAdd.getPhoneNumber() + "','"
                                    + curentContactToAdd.getDaysUntilBirthdayAsString() + "');"
                                    ,null);
                        }

                        Log.i("tag","List initialization completed"); // log info
                    }
                });

            }
        });
    }

    /**
     * delete a Contact by its phone number
     * @param phoneNumber a String representing the phone number of the Contact to be deleted
     */
    @JavascriptInterface
    @Override
    public void deleteContactByPhoneNumber(final String phoneNumber){
        threadPool.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    Log.i("tag","Asking the Model to delete a Contact");
                    model.deleteSingleContact(phoneNumber);
                    showConfirmContactDeletedMessage();
                    Log.i("tag","deleted successfully");
                }
               catch (HITMOBILEException e){
                    Log.e("tag", "something went wrong, could not delete the Contact with phone number = " + phoneNumber +". Printing message:");
                    Log.e("tag", e.getMessage());
               }
            }
        });
    }

    /**
     * Show confirmation message (new contact added)
     */
    @JavascriptInterface
    @Override
    public void showConfirmContactAddedMessage(){
        theActivity.runOnUiThread(new Runnable() { // show message on the UI thread
            @Override
            public void run() { // on UI thread
                Toast.makeText(theActivity.getApplicationContext(),"new contact added successfully",
                        Toast.LENGTH_LONG).show(); // show Toast message
            }
        });
    }

    /**
     * Show Error message (new contact could not be added)
     */
    @JavascriptInterface
    @Override
    public void showErrorContactNotAddedMessage(){
        theActivity.runOnUiThread(new Runnable() { // show message on the UI thread
            @Override
            public void run() { // on UI thread
                Toast.makeText(theActivity.getApplicationContext(),"Error! Please make sure you have entered something to every text field \n " +
                                "The names should contain only english letters\n" +
                                "Phone number should contain 10 digits",
                        Toast.LENGTH_LONG).show(); // show Toast message
            }
        });
    }

    /**
     * Show confirmation message (contact deleted)
     */
    @Override
    public void showConfirmContactDeletedMessage(){
        theActivity.runOnUiThread(new Runnable() { // show message on the UI thread
            @Override
            public void run() { // on UI thread
                Toast.makeText(theActivity.getApplicationContext(),"contact deleted successfully",
                        Toast.LENGTH_LONG).show(); // show Toast message
            }
        });
    }
}
