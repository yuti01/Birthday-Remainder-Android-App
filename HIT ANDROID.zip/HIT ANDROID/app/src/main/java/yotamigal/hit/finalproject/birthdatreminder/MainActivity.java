package yotamigal.hit.finalproject.birthdatreminder;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import android.widget.VideoView;

import java.time.LocalDate;

import yotamigal.hit.finalproject.birthdatreminder.exception.HITMOBILEException;
import yotamigal.hit.finalproject.birthdatreminder.model.Contact;
import yotamigal.hit.finalproject.birthdatreminder.model.ContactList;
import yotamigal.hit.finalproject.birthdatreminder.model.Gender;
import yotamigal.hit.finalproject.birthdatreminder.model.IModel;
import yotamigal.hit.finalproject.birthdatreminder.model.Model;
import yotamigal.hit.finalproject.birthdatreminder.viewmodel.IViewModel;
import yotamigal.hit.finalproject.birthdatreminder.viewmodel.ViewModel;

/**
 * The MainActivity of this project
 * This code runs first
 */
public class MainActivity extends AppCompatActivity {

    /**
     * theWebView is the WebView object associated with this Activity
     * The GUI shows inside it
     */
    private WebView theWebView; // the WebView object associated with this Activity

    /**
     * This method initializes the Activity
     * @param savedInstanceState a Bundle object related to the "onCreate" call
     */
    @SuppressLint("SetJavaScriptEnabled")     // enabling JavaScript usage
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); // calling the super onCreate method

        Log.i("tag","Starting the App"); // Log info

        final IModel model = new Model(getApplicationContext()); // create the Model

        final WebView webView = new WebView(this); // creating the WebView object

        theWebView = webView; // set the WebView attribute

        final IViewModel vm = new ViewModel(model, webView, this); // create the ViewModel

        setContentView(webView); // set the WebView object as the View of the App

        webView.getSettings().setJavaScriptEnabled(true); // set javascript enabled on this WebView

        runOnUiThread(new Runnable() { // in the UI thread
            @Override
            public void run() {
                Log.i("tag","Adding the ViewModel to the JavaScript"); // logging some info

                webView.addJavascriptInterface(vm, "vm"); // inject the ViewModel object into the WebView

                Log.i("tag","Loading URL"); // logging some info

                webView.loadUrl("file:///android_asset/index.html"); // loading the html file into the WebView

                Log.i("tag","URL loaded"); // logging some info
            }
        });

        Log.i("tag", "onCreate is done"); // logging some info
    }

    /**
     * This method is called when the user clicks the android back button
     * we override it to change the default behavior of this button
     */
    @Override
    public void onBackPressed() {
        Log.i("tag","go back"); // logging some info

        String javascript = "hit.getCurrentPage();"; // the JavaScript script we use to get the current page

        ValueCallback<String> answerFromJavaScript = new ValueCallback<String>() { // what to do when we get info back
            @Override
            public void onReceiveValue(String value) {

                if (value.equals("\"page-one\"")){ // in the first page
                    Log.i("tag","back from \"page-one\""); // logging info
                    exitAppGoToHomeScreen(); // back to home screen
                } else {
                    Log.i("tag","back from another page (id = " + value + ")");  // logging some info

                    // change the page - go back to the page "page-one"
                    theWebView.evaluateJavascript("$.mobile.changePage(\"#page-one\");",null);
                }
            }
        };

        theWebView.evaluateJavascript(javascript,answerFromJavaScript); // run the JavaScript script to get the answer

    }

    /**
     * This method is used to exit the app and returning to the home screen of the android device
     */
    private void exitAppGoToHomeScreen(){
        super.onBackPressed(); // call the super function - in this situation this is exactly what we need
    }
}

