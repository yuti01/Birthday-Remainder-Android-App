package yotamigal.hit.finalproject.birthdatreminder.model;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.BaseColumns;
import android.util.Log;

import java.time.LocalDate;
import java.util.ArrayList;

import yotamigal.hit.finalproject.birthdatreminder.exception.HITMOBILEException;
import yotamigal.hit.finalproject.birthdatreminder.model.ContactContract.ContactEntry;

/**
 * This class is the Model class for this project
 */
public class Model implements IModel{

    /**
     * context - the Context of this Model instance
     * dbHelper - the data base helper
     */
    Context context; // the Context of this Model instance

    ContactDbHelper dbHelper; // the data base helper

    /**
     * The constructor of this class
     * @param context the Context of this Model instance
     */
    public Model(Context context) {
        this.context = context; // set the Context object
    }

    /**
     * This method puts Contact in the data base
     * @param contact the Contact to put inside the data base
     */
    @Override
    public void putContactInDB(Contact contact) {

        Log.i("tag","putting a contact inside the data base");

        dbHelper = new ContactDbHelper(context); // init the DB Helper

        // Gets the data repository in write mode
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Create a new map of values, where column names are the keys
        ContentValues values = new ContentValues();
        values.put(ContactEntry.COLUMN_FIRST_NAME, contact.getFirstName());
        values.put(ContactEntry.COLUMN_LAST_NAME, contact.getLastName());
        values.put(ContactEntry.COLUMN_GENDER, contact.getGender().toString());
        values.put(ContactEntry.COLUMN_PHONE_NUMBER, contact.getPhoneNumber());
        values.put(ContactEntry.COLUMN_DATE_OF_BIRTH,contact.getDateOfBirth().toString());

        // Insert the new row, returning the primary key value of the new row
        long newRowId = db.insert(ContactEntry.TABLE_NAME, null, values);

        dbHelper.close(); // close the DB Helper
    }

    /**
     * This method gets a specific Contact from the data base found by the phone number of the Contact
     * @param phoneNumber a String representing the phone number of the Contact that the method returns
     * @return a Contact object with the data from the data base with the specified phone number
     */
    @Override
    public Contact getContactFromDB(String phoneNumber){

        Log.i("tag","getting the Contact with phone number" + phoneNumber);

        dbHelper = new ContactDbHelper(context); // init the DB Helper

        SQLiteDatabase db = dbHelper.getReadableDatabase(); // get the data base

        // we define a projection that specifies which columns from the database
        // we will actually use after this query.
        String[] projection = {
                ContactEntry.COLUMN_FIRST_NAME,
                ContactEntry.COLUMN_LAST_NAME,
                ContactEntry.COLUMN_GENDER,
                ContactEntry.COLUMN_PHONE_NUMBER,
                ContactEntry.COLUMN_DATE_OF_BIRTH
        };

        // Filter results WHERE "title" = 'My Title'
        String selection = ContactEntry.COLUMN_PHONE_NUMBER + " = ?";
        String[] selectionArgs = { phoneNumber };


        Cursor cursor = db.query(
                ContactEntry.TABLE_NAME,   // The table to query
                projection,             // The array of columns to return (pass null to get all)
                selection,              // The columns for the WHERE clause
                selectionArgs,          // The values for the WHERE clause
                null,                   // don't group the rows
                null,                   // don't filter by row groups
                null               // The sort order - null - no need to sort
        );

        cursor.moveToNext();
        try {
            int index;

            index = cursor.getColumnIndexOrThrow(ContactEntry.COLUMN_FIRST_NAME); // get the index
            String firstName = cursor.getString(index); // get the value

            index = cursor.getColumnIndexOrThrow(ContactEntry.COLUMN_LAST_NAME); // get the index
            String lastName = cursor.getString(index); // get the value

            index = cursor.getColumnIndexOrThrow(ContactEntry.COLUMN_GENDER); // get the index
            Gender gender = Gender.parseString(cursor.getString(index)); // get the value

            index = cursor.getColumnIndexOrThrow(ContactEntry.COLUMN_DATE_OF_BIRTH); // get the index
            LocalDate date = LocalDate.parse(cursor.getString(index)); // get the value

            // Create a new Contact with the data
            Contact contact = new Contact(firstName, lastName, gender, date, phoneNumber);
            return contact; // and return it
        } catch (HITMOBILEException e) {
            Log.e("model error","phone number is not in the right format"); // Log error message
        } finally {
            dbHelper.close(); // close the DB Helper
        }

        return null; // if something went wrong return null
    }

    /**
     * Get all the Contacts from the database
     * @return a ContactList object containing all the Contacts from the database
     */
    @Override
    public ContactList getAllContactFromDB(){
        Log.i("tag","getting all the contacts");

        dbHelper = new ContactDbHelper(context); // init the DB Helper

        SQLiteDatabase db = dbHelper.getReadableDatabase(); // get the data base

        Cursor cursor = db.query(
                ContactEntry.TABLE_NAME,   // The table to query
                null,             // The array of columns to return (passing null to get all)
                null,              // The columns for the WHERE clause (passing null for mo WHERE condition)
                null,          // The values for the WHERE clause (passing null for mo WHERE condition)
                null,                   // don't group the rows
                null,                   // don't filter by row groups
                null               // The sort order - null - no need to sort
        );

        ArrayList<Contact> contacts = new ArrayList<>(); // define an array list to store all the contact in

        while (cursor.moveToNext()){ // iterate over the cursor

            // collect data from the cursor

            int index; // an index of the current column we extract from the cursor

            index = cursor.getColumnIndexOrThrow(ContactEntry.COLUMN_FIRST_NAME); // get the index
            String firstName = cursor.getString(index); // get the value

            index = cursor.getColumnIndexOrThrow(ContactEntry.COLUMN_LAST_NAME); // get the index
            String lastName = cursor.getString(index); // get the value

            index = cursor.getColumnIndexOrThrow(ContactEntry.COLUMN_GENDER); // get the index
            Gender gender = Gender.parseString(cursor.getString(index)); // get the value

            index = cursor.getColumnIndexOrThrow(ContactEntry.COLUMN_PHONE_NUMBER); // get the index
            String  phoneNumber = cursor.getString(index); // get the value

            index = cursor.getColumnIndexOrThrow(ContactEntry.COLUMN_DATE_OF_BIRTH); // get the index
            LocalDate date = LocalDate.parse(cursor.getString(index)); // get the value


            try {
                Contact contact = new Contact(firstName, lastName, gender, date, phoneNumber); // create a new Contact from the data collected
                contacts.add(contact); // add the new Contact to the list
            } catch (HITMOBILEException e) {
               Log.e("tag","phone number error - phone number is not in the right format"); // log error message
            } finally {
                dbHelper.close(); // close the DB Helper
            }

        } // END of the WHILE LOOP

        return new ContactList(contacts); // make the ArrayList a ContactList and return it
    }

    /**
     * get the number of Contacts in the database
     * @return an integer representing the number of Contacts in the database
     */
    @Override
    public int getNumOfContacts(){

        Log.i("tag","counting the contacts that are in the data base"); // log info

        int count; // define the count variable to be returned

        dbHelper = new ContactDbHelper(context); // init the DB Helper

        SQLiteDatabase db = dbHelper.getReadableDatabase(); // get the data base

        Cursor cursor = db.rawQuery("select count(*) from " + ContactEntry.TABLE_NAME,null); // count the rows in the data base

        cursor.moveToFirst(); // move to the first line in the cursor

        count = cursor.getInt(0); // get the value

        cursor.close(); // close the cursor

        dbHelper.close(); // close the DB Helper

        return count; // return the value in count
    }

    /**
     * delete a Contact from the database
     * @param phoneNumber a String representing the phone number of the Contact to be deleted
     * @throws HITMOBILEException if the deletion went wrong
     */
    @Override
    public void deleteSingleContact(String phoneNumber) throws HITMOBILEException{
        dbHelper = new ContactDbHelper(context); // init the DB Helper

        SQLiteDatabase db = dbHelper.getWritableDatabase(); // get database

        Log.i("tag","Deleting a Contact with phone number: " + phoneNumber); // log info

        // execute the deletion
        int numOfRowsChanged = db.delete(ContactEntry.TABLE_NAME,ContactEntry.COLUMN_PHONE_NUMBER + "='" + phoneNumber + "'" ,null);

        if (numOfRowsChanged != 1) // if wrong number of rows has changed throw exception
        {
            throw new HITMOBILEException("unexpected number of rows has changed (" + numOfRowsChanged + "!=1)");
        }

        Log.i("tag","Contact deleted"); // log info

        dbHelper.close(); // close the connection to the database
    }

    /**
     * This method clears the database - delete all rows
     */
    @Override
    public void clearTheDataBase(){
        Log.i("tag","getting connection");
        dbHelper = new ContactDbHelper(context); // init the DB Helper

        SQLiteDatabase db = dbHelper.getWritableDatabase(); // get database

        if (db == null) Log.i("tag","db is null");
        Log.i("tag","Clearing the database - Deleting all Contacts"); // log info

        // execute the deletion
        db.delete(ContactEntry.TABLE_NAME, null, null);

        Log.i("tag","Database cleared"); // log info

        dbHelper.close(); // close the connection to the database
    }
}

