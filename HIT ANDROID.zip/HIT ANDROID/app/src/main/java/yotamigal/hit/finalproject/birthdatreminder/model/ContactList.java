package yotamigal.hit.finalproject.birthdatreminder.model;

import android.webkit.JavascriptInterface;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * THis class represents a List of Contacts
 */
public class ContactList implements Iterable<Contact>{

    /**
     * contacts - the List of Contacts
     */
    private ArrayList<Contact> contacts; // ArrayList of Contacts

    /**
     * the Constructor of this class
     * @param contacts an ArrayList of Contacts to be used
     */
    public ContactList(ArrayList<Contact> contacts) {
        setContacts(contacts);
    }

    /**
     * getter for the Contact List
     * @return an ArrayList of Contacts representing the List of Contacts in this ContactList object
     */
    public ArrayList<Contact> getContacts() {
        return contacts;
    }

    /**
     * A setter for the "contact" field
     * @param contacts an ArrayList of Contacts representing the List of Contacts to be
     *                 the List of Contact of this ContactList object
     */
    public void setContacts(ArrayList<Contact> contacts) {
        this.contacts = contacts; // set the "contact" field
    }

    /**
     * get a Contact in a specific index
     * @param i an integer - the index of the wanted Contact
     * @return the Contact in index i
     */
    @JavascriptInterface
    public Contact getContactInIndex(int i){
        return getContacts().get(i);
    }

    /**
     * get the number of Contacts in this List
     * @return the size of the Contact list
     */
    @JavascriptInterface
    public int howManyContacts(){
        return getContacts().size(); // return the size of the list
    }

    /**
     * check if this ContactList is empty
     * @return true - if this ContactList is empty
     *         false - otherwise
     */
    public boolean isEmpty() { return getContacts().isEmpty(); }

    /**
     * Returns an iterator over elements of type {@code Contact}.
     * @return an Iterator.
     */
    @NonNull
    @Override
    public Iterator<Contact> iterator() {
        return contacts.iterator();
    }
}
