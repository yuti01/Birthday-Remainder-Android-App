package yotamigal.hit.finalproject.birthdatreminder.model;

import android.provider.BaseColumns;

/**
 * This class defines the structure of the SQLite database
 * we make it final so no one accidentally tries to extend this class
 */
public final class ContactContract {

    /**
     * the Constructor of this class - we make it private
     * to prevent someone from accidentally instantiating the contract class
     */
    // To prevent someone from accidentally instantiating the contract class,
    // we make the constructor private.
    private ContactContract(){}

    /**
     * This class defines the table contents
     */
    /* Inner class that defines the table contents */
    public static class ContactEntry implements BaseColumns {
        public static final String TABLE_NAME = "contacts"; // table name
        public static final String COLUMN_FIRST_NAME = "first_name"; // the columns
        public static final String COLUMN_LAST_NAME = "last_name";
        public static final String COLUMN_GENDER = "gender";
        public static final String COLUMN_PHONE_NUMBER = "phone_number";
        public static final String COLUMN_DATE_OF_BIRTH = "date_of_birth";
    }

}
